import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:dear_days/features/auth/bloc/auth_bloc.dart';
import 'package:dear_days/features/auth/bloc/auth_event.dart';
import 'package:dear_days/features/auth/bloc/auth_state.dart';

class LoginPage extends StatelessWidget {
  const LoginPage({super.key});
  final authRepo = AuthRepository();
authRepo.sendOtp(phoneNumber);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: BlocConsumer<AuthBloc, AuthState>(
        listener: (context, state) {
          if (state is AuthError) {
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(content: Text(state.message)),
            );
          } else if (state is OtpSentSuccessfully) {
            ScaffoldMessenger.of(context).showSnackBar(
              const SnackBar(content: Text("OTP Sent!")),
            );
            // 👉 Navigate to OTP Verification Page here
          }
        },
        builder: (context, state) {
          return Center(
            child: state is AuthLoading
                ? const CircularProgressIndicator()
                : ElevatedButton(
                    onPressed: () => _loginWithPhone(context),
                    child: const Text("Login with Phone"),
                  ),
          );
        },
      ),
    );
  }

  void _loginWithPhone(BuildContext context) async {
    final phoneNumber = await _showPhoneInputDialog(context);
    if (phoneNumber != null && phoneNumber.isNotEmpty) {
      context.read<AuthBloc>().add(LoginWithPhoneNumberStarted(phoneNumber));
    }
  }

  Future<String?> _showPhoneInputDialog(BuildContext context) {
    final controller = TextEditingController();
    return showDialog<String>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text("Enter your phone number"),
        content: TextField(
          controller: controller,
          keyboardType: TextInputType.phone,
          decoration: const InputDecoration(hintText: "+91XXXXXXXXXX"),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, controller.text),
            child: const Text("Send OTP"),
          ),
        ],
      ),
    );
  }
}
